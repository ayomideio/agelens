class Products {
  final String productName;
  final String shippingNumber;
  final String location;

  Products({required this.productName, required this.shippingNumber,required this.location,});
}
