class OnBoardingText {
  static const title1 = "Welcome to Issy Travel";
  static const subTitle1 =
      "Your trusted companion for exploring the world's most user-focused captivating destination travel ";
  static const lastTitle1 = "experience.";
  static const title2 = "Explore Hidden Gems";
  static const subTitle2 =
      "Uncover unique attractions, enjoy personalized recommendations, and create very unique unforgettable memories organically effortlessly";
  static const lastTitle2 = " with ease!";
  static const title3 = "Stay Informed, Stay Adventurous";
  static const subTitle3 =
      "Experience the world like never before. Issy Travel equips you with the tools\n       to plan and enjoy your trips";
  static const lastTitle3 = "anytime, anywhere.";
}
