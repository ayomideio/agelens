// import 'package:intl/intl.dart';
// import 'dart:io';

// class Currency {

//   String getCurrency() {
//     var format =
//         NumberFormat.simpleCurrency(locale: Platform.localeName, name: 'GBP');
//     return format.currencySymbol;
//   }
// }
