package com.example.readmitpredictor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
